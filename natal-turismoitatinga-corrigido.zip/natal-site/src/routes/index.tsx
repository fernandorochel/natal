import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Instagram,
  MessageCircle,
  Snowflake,
  MapPin,
  Clock,
  ChevronDown,
  ArrowRight,
  Accessibility,
  CalendarDays,
  Menu,
  X,
  Mail,
  Sparkles,
  TreePine,
  Trophy,
  BellRing,
  Heart,
  Store,
  Lightbulb,
  Users,
  Landmark,
} from "lucide-react";

import heroImg from "@/assets/hero-natal.jpg";
import corridaImg from "@/assets/corrida-natal.jpg";
import logoAsset from "@/assets/logo-natal.png.asset.json";
import logoPrefeituraAsset from "@/assets/logo-prefeitura.png.asset.json";
import FloatingChristmas from "@/components/FloatingChristmas";
import CookieConsent from "@/components/CookieConsent";

const SITE_URL = "https://natal.turismoitatinga.com.br";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "II Festival Natalino de Itatinga 2026 — Programação, Corrida Natal e Novidades" },
      { name: "description", content: "Portal oficial do II Festival Natalino de Itatinga 2026: iluminação, decoração temática, apresentações culturais gratuitas e Corrida Natal em 13/12/2026 na Praça da Matriz." },
      { property: "og:title", content: "II Festival Natalino de Itatinga 2026" },
      { property: "og:description", content: "Portal oficial: iluminação, cultura, Corrida Natal e programação gratuita em Itatinga/SP. Novidades a partir de outubro." },
      { property: "og:url", content: `${SITE_URL}/` },
      { property: "og:type", content: "website" },
      { property: "og:image", content: `${SITE_URL}${heroImg}` },
      { property: "og:image:alt", content: "Festival Natalino de Itatinga — decoração e iluminação natalina na Praça da Matriz" },
      { name: "twitter:image", content: `${SITE_URL}${heroImg}` },
    ],
    links: [
      { rel: "canonical", href: `${SITE_URL}/` },
      { rel: "preload", as: "image", href: heroImg, fetchpriority: "high" },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Event",
          name: "II Festival Natalino de Itatinga 2026",
          eventStatus: "https://schema.org/EventScheduled",
          eventAttendanceMode: "https://schema.org/OfflineEventAttendanceMode",
          startDate: "2026-12-01",
          endDate: "2026-12-25",
          image: [`${SITE_URL}${heroImg}`],
          url: `${SITE_URL}/`,
          location: {
            "@type": "Place",
            name: "Praça da Matriz",
            address: {
              "@type": "PostalAddress",
              addressLocality: "Itatinga",
              addressRegion: "SP",
              addressCountry: "BR",
            },
          },
          organizer: {
            "@type": "GovernmentOrganization",
            name: "Prefeitura Municipal de Itatinga — Diretoria Municipal de Lazer, Turismo e Eventos",
          },
          offers: {
            "@type": "Offer",
            price: "0",
            priceCurrency: "BRL",
            availability: "https://schema.org/InStock",
          },
          description:
            "Evento cultural gratuito que integra o calendário municipal de Itatinga, valorizando a cultura local, o turismo e a convivência familiar. Programação oficial em atualização.",
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          name: "Festival Natalino de Itatinga",
          inLanguage: "pt-BR",
          description: "Portal oficial do II Festival Natalino de Itatinga 2026.",
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "GovernmentOrganization",
          name: "Prefeitura Municipal de Itatinga",
          department: {
            "@type": "GovernmentOrganization",
            name: "Diretoria Municipal de Lazer, Turismo e Eventos",
          },
          areaServed: {
            "@type": "City",
            name: "Itatinga",
          },
        }),
      },
    ],
  }),
});

// -------------------- DATA --------------------
const faqs = [
  {
    q: "O acesso ao festival é gratuito?",
    a: "Sim. O Festival Natalino de Itatinga é um evento público e gratuito, realizado em espaço aberto para toda a comunidade e visitantes.",
  },
  {
    q: "Onde o evento é realizado?",
    a: "As atividades acontecem em espaços públicos do município de Itatinga, com destaque para a Praça da Matriz. A programação completa com locais e horários será divulgada oficialmente pela organização.",
  },
  {
    q: "Há acessibilidade para pessoas com deficiência?",
    a: "Sim. Por ser realizado em ambiente aberto e público, o local é acessível para pessoas com deficiência e mobilidade reduzida.",
  },
  {
    q: "Onde estacionar?",
    a: "Os visitantes podem utilizar as vias públicas permitidas pelo trânsito no entorno dos locais do evento, respeitando a sinalização.",
  },
  {
    q: "Posso levar meu pet?",
    a: "Sim, os pets são bem-vindos. Recomendamos o uso de guia e a atenção com o bem-estar do animal durante a visita.",
  },
];

const highlights = [
  {
    Icon: TreePine,
    tag: "FESTIVAL",
    title: "II Festival Natalino 2026",
    desc: "Celebração pública com iluminação, decoração temática, atividades culturais e ações voltadas à convivência das famílias.",
  },
  {
    Icon: Trophy,
    tag: "CORRIDA",
    title: "Corrida Natal 2026",
    desc: "Atividade esportiva integrante da programação natalina, com realização prevista para 13 de dezembro de 2026.",
  },
  {
    Icon: BellRing,
    tag: "OFICIAL",
    title: "Programação Oficial",
    desc: "A programação completa será divulgada a partir de outubro, após validação da organização do evento.",
  },
];


// -------------------- SNOWFALL --------------------
function Snowfall() {
  const [enabled, setEnabled] = useState(true);
  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const mobile = window.matchMedia("(max-width: 768px)");
    setEnabled(!media.matches);
    const listener = () => setEnabled(!media.matches && !mobile.matches ? true : !media.matches);
    media.addEventListener("change", listener);
    return () => media.removeEventListener("change", listener);
  }, []);

  const flakes = useMemo(() => {
    const count = typeof window !== "undefined" && window.matchMedia("(max-width: 768px)").matches ? 14 : 24;
    return Array.from({ length: count }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      size: Math.random() * 2.5 + 1,
      duration: Math.random() * 10 + 10,
      delay: Math.random() * 12,
      opacity: Math.random() * 0.4 + 0.2,
    }));
  }, []);

  if (!enabled) return null;
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-[1] overflow-hidden">
      {flakes.map((f) => (
        <span
          key={f.id}
          className="absolute top-0 rounded-full bg-white"
          style={{
            left: `${f.left}%`,
            width: `${f.size}px`,
            height: `${f.size}px`,
            opacity: f.opacity,
            filter: "blur(0.4px)",
            boxShadow: "0 0 4px rgba(255,255,255,0.45)",
            animation: `snowfall ${f.duration}s linear ${f.delay}s infinite`,
          }}
        />
      ))}
    </div>
  );
}

// -------------------- HERO PARALLAX --------------------
function useParallax<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  useEffect(() => {
    let raf = 0;
    let ticking = false;
    const update = () => {
      const el = ref.current;
      if (el) {
        const y = window.scrollY;
        el.style.transform = `translate3d(0, ${y * 0.25}px, 0)`;
      }
      ticking = false;
    };
    const onScroll = () => {
      if (!ticking) {
        ticking = true;
        raf = requestAnimationFrame(update);
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    update();
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);
  return ref;
}

// -------------------- COMPONENT --------------------
function Index() {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [mobileOpen, setMobileOpen] = useState(false);
  const parallaxRef = useParallax<HTMLDivElement>();

  const nav = [
    { href: "#top", label: "Início" },
    { href: "#sobre", label: "Sobre o Evento" },
    { href: "#programacao", label: "Programação" },
    { href: "#corrida", label: "Corrida Natal" },
    { href: "#faq", label: "Dúvidas" },
    { href: "#contato", label: "Contato" },
  ];

  return (
    <div className="relative min-h-screen text-foreground overflow-x-hidden">
      <Snowfall />
      <FloatingChristmas />
      <CookieConsent />

      {/* NAV */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#0B132B]/85 backdrop-blur-md border-b border-white/8">
        <div className="max-w-7xl mx-auto grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-2.5 md:py-3">
          <a href="#top" className="flex items-center gap-3 leading-none min-w-0" aria-label="Ir para o início">
            <img
              src={logoAsset.url}
              alt="Festival Natalino de Itatinga"
              width="96"
              height="48"
              decoding="async"
              className="h-9 md:h-11 w-auto shrink-0"
            />
            <span className="hidden sm:inline truncate text-[13px] md:text-sm font-medium tracking-wide text-white/85">
              Festival Natalino de Itatinga
            </span>
          </a>
          <nav
            aria-label="Navegação principal"
            className="hidden lg:flex items-center gap-7 text-sm text-white/80 font-medium"
          >
            {nav.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="hover:text-[color:var(--gold)] transition-colors"
              >
                {n.label}
              </a>
            ))}
          </nav>
          <button
            type="button"
            aria-label={mobileOpen ? "Fechar menu" : "Abrir menu"}
            aria-expanded={mobileOpen}
            aria-controls="mobile-nav"
            onClick={() => setMobileOpen((v) => !v)}
            className="lg:hidden inline-flex shrink-0 items-center justify-center w-10 h-10 rounded-lg border border-white/15 text-white/90 hover:border-[color:var(--gold)]/50 transition"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
        {mobileOpen && (
          <div id="mobile-nav" className="lg:hidden border-t border-white/10 bg-[#0B132B]/95 backdrop-blur-xl">
            <nav aria-label="Navegação móvel" className="px-4 py-3 flex flex-col text-sm max-h-[75vh] overflow-y-auto">
              {nav.map((n) => (
                <a
                  key={n.href}
                  href={n.href}
                  onClick={() => setMobileOpen(false)}
                  className="py-3 px-3 rounded-lg text-white/85 border-b border-white/5 last:border-b-0 hover:bg-white/5 hover:text-[color:var(--gold)] transition-colors"
                >
                  {n.label}
                </a>
              ))}
            </nav>
          </div>
        )}
      </header>

      {/* HERO */}
      <section
        id="top"
        className="relative min-h-[92vh] md:min-h-screen flex items-center justify-center pt-28 pb-16 overflow-hidden"
      >
        <div ref={parallaxRef} className="absolute inset-0 z-0 will-change-transform">
          <img
            src={heroImg}
            alt="Vista aérea noturna da Praça da Matriz de Itatinga decorada para o Natal 2026"
            fetchPriority="high"
            decoding="async"
            className="w-full h-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0B132B]/78 via-[#0B132B]/85 to-[#0B132B]" />
        </div>

        <div className="relative z-10 max-w-3xl mx-auto px-6 w-full text-center">
          <div className="inline-flex items-center gap-2 text-[10px] md:text-[11px] tracking-[0.35em] text-[color:var(--gold)]/90 mb-8">
            <Snowflake className="w-3 h-3" />
            SITE OFICIAL · PRÉ-LANÇAMENTO
          </div>

          <h1 className="font-display font-semibold uppercase tracking-[0.01em] text-[2.25rem] leading-[1.08] sm:text-5xl md:text-6xl lg:text-7xl text-gold-gradient">
            II Festival Natalino<br />de Itatinga 2026
          </h1>

          <p className="mt-6 md:mt-8 font-serif text-lg md:text-2xl text-white/85 leading-relaxed max-w-2xl mx-auto">
            O Natal de Itatinga em uma celebração de luz, cultura, convivência familiar e valorização dos
            espaços públicos.
          </p>

          <div className="mt-8 flex flex-wrap justify-center items-center gap-x-6 gap-y-2 text-xs md:text-sm text-white/70">
            <span className="inline-flex items-center gap-2">
              <CalendarDays className="w-4 h-4 text-[color:var(--gold)]" />
              Dezembro de 2026
            </span>
            <span className="hidden sm:inline text-white/25">·</span>
            <span className="inline-flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[color:var(--gold)]" />
              Praça da Matriz — Itatinga/SP
            </span>
          </div>

          <div className="mt-10 flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center items-stretch sm:items-center">
            <a
              href="#programacao"
              className="btn-gold px-6 py-3 rounded-full text-xs md:text-sm uppercase tracking-widest transition hover:-translate-y-0.5 inline-flex items-center justify-center gap-2"
            >
              Acompanhar novidades <ArrowRight className="w-4 h-4" />
            </a>
            <a
              href="#sobre"
              className="px-6 py-3 rounded-full text-xs md:text-sm uppercase tracking-widest border border-white/25 text-white/85 hover:border-[color:var(--gold)]/60 hover:text-white transition inline-flex items-center justify-center"
            >
              Ver informações do evento
            </a>
          </div>

          <p className="mt-10 text-[11px] md:text-xs tracking-[0.25em] text-white/45 uppercase">
            Programação oficial em atualização
          </p>
        </div>
      </section>

      {/* SOBRE */}
      <section id="sobre" className="relative py-20 md:py-28 z-10 scroll-mt-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center mb-14">
            <p className="text-xs tracking-[0.4em] text-[color:var(--gold)] mb-4">SOBRE O EVENTO</p>
            <h2 className="font-serif text-3xl md:text-5xl leading-tight mb-6">
              Uma tradição do <em className="text-gold-gradient not-italic">calendário municipal</em>
            </h2>
            <p className="text-base md:text-lg text-white/80 leading-relaxed">
              O Festival Natalino de Itatinga integra o calendário oficial do município e tem como finalidade
              valorizar a convivência familiar, fortalecer a cultura local e estimular o turismo.
            </p>
            <p className="mt-4 text-base md:text-lg text-white/70 leading-relaxed">
              A cada edição, a iluminação natalina, a decoração temática e a programação cultural ocupam de forma
              qualificada os espaços públicos, movimentando o comércio e reunindo moradores e visitantes em torno
              de uma tradição que já faz parte da identidade da cidade.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              {
                Icon: Heart,
                title: "Cultura e tradição",
                desc: "Apresentações culturais e valorização das expressões artísticas locais.",
              },
              {
                Icon: Store,
                title: "Turismo e economia local",
                desc: "Movimentação do comércio, dos serviços e atração de visitantes à cidade.",
              },
              {
                Icon: Users,
                title: "Convivência familiar",
                desc: "Atividades pensadas para famílias, em espaço aberto e acolhedor.",
              },
              {
                Icon: Lightbulb,
                title: "Iluminação e decoração",
                desc: "Iluminação natalina e decoração temática nos principais pontos públicos.",
              },
              {
                Icon: Landmark,
                title: "Espaços públicos",
                desc: "Ocupação qualificada da Praça da Matriz e outros pontos do município.",
              },
              {
                Icon: Sparkles,
                title: "Programação gratuita",
                desc: "Evento público e gratuito, com programação em atualização para 2026.",
              },
            ].map(({ Icon, title, desc }) => (
              <article
                key={title}
                className="rounded-2xl p-6 bg-white/[0.03] border border-white/10 hover:border-[color:var(--gold)]/35 transition-colors"
              >
                <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-[color:var(--gold)]/10 border border-[color:var(--gold)]/20 mb-4">
                  <Icon className="w-4 h-4 text-[color:var(--gold)]" />
                </div>
                <h3 className="font-serif text-lg md:text-xl mb-1.5 text-white">{title}</h3>
                <p className="text-sm text-white/65 leading-relaxed">{desc}</p>
              </article>
            ))}
          </div>

          <p className="mt-10 text-center text-sm text-white/55 leading-relaxed max-w-2xl mx-auto">
            Organização conduzida pela Prefeitura Municipal de Itatinga, por meio da Diretoria Municipal de
            Lazer, Turismo e Eventos.
          </p>
        </div>
      </section>

      {/* DESTAQUES */}
      <section id="destaques" className="relative py-16 md:py-24 z-10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12 reveal">
            <p className="text-xs tracking-[0.4em] text-[color:var(--gold)] mb-4">DESTAQUES</p>
            <h2 className="font-serif text-3xl md:text-5xl">
              Destaques do <em className="text-gold-gradient not-italic">Festival</em>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {highlights.map(({ Icon, tag, title, desc }) => (
              <article
                key={title}
                className="glass rounded-2xl p-7 border border-white/10 hover:border-[color:var(--gold)]/40 transition-all hover:-translate-y-1"
              >
                <div className="w-12 h-12 rounded-full flex items-center justify-center bg-[color:var(--gold)]/12 border border-[color:var(--gold)]/25 mb-5">
                  <Icon className="w-5 h-5 text-[color:var(--gold)]" />
                </div>
                <p className="text-[10px] tracking-[0.35em] text-[color:var(--gold)] mb-2">{tag}</p>
                <h3 className="font-serif text-2xl mb-3">{title}</h3>
                <p className="text-sm text-white/70 leading-relaxed">{desc}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* PROGRAMAÇÃO — EM BREVE */}
      <section id="programacao" className="relative py-20 md:py-28 z-10">
        <div className="max-w-4xl mx-auto px-6">
          <div className="glass rounded-3xl border border-[color:var(--gold)]/25 p-10 md:p-14 text-center reveal">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-[color:var(--gold)]/12 border border-[color:var(--gold)]/30 mb-6">
              <Sparkles className="w-6 h-6 text-[color:var(--gold)]" />
            </div>
            <p className="text-xs tracking-[0.4em] text-[color:var(--gold)] mb-3">PROGRAMAÇÃO OFICIAL</p>
            <h2 className="font-serif text-3xl md:text-5xl leading-tight mb-5">
              Em breve, a magia<br />ganha data e hora
            </h2>
            <p className="text-base md:text-lg text-white/75 max-w-2xl mx-auto leading-relaxed">
              A programação completa do II Festival Natalino de Itatinga 2026 está em fase de construção. Após
              validação da organização, todas as atrações, datas e locais serão publicados oficialmente neste
              site — previsão a partir de outubro de 2026.
            </p>
            <div className="mt-8 flex flex-wrap gap-3 justify-center text-xs">
              <span className="glass px-4 py-2 rounded-full text-white/70 border border-white/10">
                Iluminação natalina
              </span>
              <span className="glass px-4 py-2 rounded-full text-white/70 border border-white/10">
                Apresentações culturais
              </span>
              <span className="glass px-4 py-2 rounded-full text-white/70 border border-white/10">
                Casa do Papai Noel
              </span>
              <span className="glass px-4 py-2 rounded-full text-white/70 border border-white/10">
                Praça de alimentação
              </span>
              <span className="glass px-4 py-2 rounded-full text-white/70 border border-white/10">
                Decoração temática
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* CORRIDA NATAL 2026 */}
      <section id="corrida" className="relative py-16 md:py-24 z-10 scroll-mt-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="relative overflow-hidden rounded-3xl glass border border-white/10">
            <img
              src={corridaImg}
              alt="Corrida Natal 2026 em Itatinga"
              loading="lazy"
              decoding="async"
              className="absolute inset-0 w-full h-full object-cover opacity-25"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0B132B]/95 via-[#0B132B]/75 to-[#0B132B]/40" />
            <div className="relative p-8 md:p-14 max-w-2xl">
              <p className="text-xs tracking-[0.4em] text-[color:var(--gold)] mb-4">CORRIDA NATAL 2026</p>
              <h2 className="font-serif text-3xl md:text-5xl leading-tight mb-3">
                Corrida Natal <em className="text-gold-gradient not-italic">2026</em>
              </h2>
              <p className="text-base md:text-lg text-white/85 mb-5">
                Esporte, integração e celebração no calendário natalino de Itatinga.
              </p>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[color:var(--gold)]/10 border border-[color:var(--gold)]/30 mb-6">
                <Trophy className="w-4 h-4 text-[color:var(--gold)]" />
                <span className="text-sm tracking-wide text-white/90">
                  Prevista para <strong className="text-[color:var(--gold)]">13 de dezembro de 2026</strong>
                </span>
              </div>
              <p className="text-sm md:text-base text-white/75 leading-relaxed mb-6">
                A Corrida Natal 2026 integrará a programação do Festival Natalino de Itatinga, promovendo
                esporte, saúde, participação comunitária e valorização dos espaços públicos.
              </p>
              <p className="text-xs md:text-sm text-white/55 leading-relaxed border-t border-white/10 pt-4">
                Informações sobre inscrições, categorias e regulamento serão divulgadas oportunamente pelos
                canais oficiais.
              </p>
            </div>
          </div>
        </div>
      </section>


      {/* INFORMAÇÕES ÚTEIS */}
      <section id="informacoes" className="relative py-16 md:py-24 z-10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12 reveal">
            <p className="text-xs tracking-[0.4em] text-[color:var(--gold)] mb-4">INFORMAÇÕES ÚTEIS</p>
            <h2 className="font-serif text-3xl md:text-5xl">Tudo o que você precisa saber</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { Icon: MapPin, title: "Local", desc: "Espaços públicos de Itatinga — SP, com destaque para a Praça da Matriz." },
              { Icon: Clock, title: "Gratuito", desc: "Evento aberto e gratuito, com acesso livre para toda a comunidade." },
              { Icon: Accessibility, title: "Acessibilidade", desc: "Realizado em ambiente aberto e acessível a pessoas com deficiência." },
              { Icon: Instagram, title: "Instagram", desc: "@turismoitatinga · novidades, bastidores e agenda cultural.", href: "https://instagram.com/turismoitatinga" },
              { Icon: MessageCircle, title: "WhatsApp", desc: "Canal institucional da Diretoria de Turismo para dúvidas.", href: "#contato" },
              { Icon: Mail, title: "Contato oficial", desc: "Fale com a Diretoria Municipal de Lazer, Turismo e Eventos.", href: "#contato" },
            ].map(({ Icon, title, desc, href }) => {
              const inner = (
                <>
                  <div className="w-11 h-11 rounded-full flex items-center justify-center bg-[color:var(--gold)]/12 border border-[color:var(--gold)]/25 mb-4">
                    <Icon className="w-5 h-5 text-[color:var(--gold)]" />
                  </div>
                  <h3 className="font-serif text-xl mb-1.5">{title}</h3>
                  <p className="text-sm text-white/70 leading-relaxed">{desc}</p>
                </>
              );
              const cls =
                "glass rounded-2xl p-6 border border-white/10 hover:border-[color:var(--gold)]/40 transition block";
              return href ? (
                <a
                  key={title}
                  href={href}
                  target={href.startsWith("http") ? "_blank" : undefined}
                  rel={href.startsWith("http") ? "noopener noreferrer" : undefined}
                  className={cls}
                >
                  {inner}
                </a>
              ) : (
                <div key={title} className={cls}>
                  {inner}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="relative py-16 md:py-24 z-10">
        <div className="max-w-3xl mx-auto px-6">
          <div className="text-center mb-10 reveal">
            <p className="text-xs tracking-[0.4em] text-[color:var(--gold)] mb-4">DÚVIDAS FREQUENTES</p>
            <h2 className="font-serif text-3xl md:text-5xl">Perguntas comuns</h2>
          </div>
          <div className="space-y-3">
            {faqs.map((f, i) => {
              const open = openFaq === i;
              return (
                <div key={f.q} className="glass rounded-2xl border border-white/10 overflow-hidden">
                  <button
                    onClick={() => setOpenFaq(open ? null : i)}
                    aria-expanded={open}
                    className="w-full flex items-center justify-between gap-4 px-5 md:px-6 py-4 text-left"
                  >
                    <span className="font-serif text-base md:text-lg text-white">{f.q}</span>
                    <ChevronDown
                      className={`w-5 h-5 shrink-0 text-[color:var(--gold)] transition-transform ${
                        open ? "rotate-180" : ""
                      }`}
                    />
                  </button>
                  {open && (
                    <div className="px-5 md:px-6 pb-5 text-sm text-white/70 leading-relaxed">{f.a}</div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CONTATO */}
      <section id="contato" className="relative py-20 md:py-28 z-10">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-10 reveal">
            <p className="text-xs tracking-[0.4em] text-[color:var(--gold)] mb-4">CONTATO</p>
            <h2 className="font-serif text-3xl md:text-5xl">Fale com a organização</h2>
            <p className="mt-4 text-white/70 max-w-2xl mx-auto">
              Diretoria Municipal de Lazer, Turismo e Eventos — Prefeitura Municipal de Itatinga.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="glass rounded-2xl p-6 border border-white/10">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[color:var(--gold)] mt-1 shrink-0" />
                <div>
                  <p className="text-xs tracking-[0.25em] text-white/60 mb-1">ENDEREÇO</p>
                  <p className="text-white/85 text-sm leading-relaxed">
                    Prefeitura Municipal de Itatinga<br />
                    Itatinga — SP
                  </p>
                </div>
              </div>
            </div>
            <div className="glass rounded-2xl p-6 border border-white/10">
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-[color:var(--gold)] mt-1 shrink-0" />
                <div>
                  <p className="text-xs tracking-[0.25em] text-white/60 mb-1">E-MAIL</p>
                  <p className="text-white/85 text-sm">turismo@itatinga.sp.gov.br</p>
                </div>
              </div>
            </div>
            <a
              href="https://instagram.com/turismoitatinga"
              target="_blank"
              rel="noopener noreferrer"
              className="glass rounded-2xl p-6 border border-white/10 hover:border-[color:var(--gold)]/40 transition block"
            >
              <div className="flex items-start gap-3">
                <Instagram className="w-5 h-5 text-[color:var(--gold)] mt-1 shrink-0" />
                <div>
                  <p className="text-xs tracking-[0.25em] text-white/60 mb-1">INSTAGRAM</p>
                  <p className="text-white/85 text-sm">@turismoitatinga</p>
                </div>
              </div>
            </a>
            <div className="glass rounded-2xl p-6 border border-white/10">
              <div className="flex items-start gap-3">
                <MessageCircle className="w-5 h-5 text-[color:var(--gold)] mt-1 shrink-0" />
                <div>
                  <p className="text-xs tracking-[0.25em] text-white/60 mb-1">WHATSAPP</p>
                  <p className="text-white/85 text-sm">Canal institucional em atualização</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="relative border-t border-white/10 bg-[#050914]/70 pt-14 pb-6 mt-4 z-10">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-10">
          <div>
            <img
              src={logoPrefeituraAsset.url}
              alt="Prefeitura Municipal de Itatinga"
              loading="lazy"
              decoding="async"
              className="h-20 w-auto object-contain drop-shadow-[0_2px_8px_rgba(0,0,0,0.5)] mb-4"
            />
            <p className="text-sm text-white/70 leading-relaxed">
              Site oficial do Festival Natalino de Itatinga, mantido pela Diretoria Municipal de Lazer, Turismo
              e Eventos.
            </p>
          </div>
          <div>
            <h4 className="text-xs tracking-[0.25em] text-white font-semibold mb-4">NAVEGAÇÃO</h4>
            <ul className="space-y-2.5 text-sm text-white/75">
              {nav.map((n) => (
                <li key={n.href}>
                  <a href={n.href} className="hover:text-[color:var(--gold)] transition">
                    {n.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="text-xs tracking-[0.25em] text-white font-semibold mb-4">INSTITUCIONAL</h4>
            <ul className="space-y-2.5 text-sm text-white/75">
              <li>Prefeitura Municipal de Itatinga</li>
              <li>Diretoria Municipal de Lazer, Turismo e Eventos</li>
              <li>
                <a
                  href="https://instagram.com/turismoitatinga"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-[color:var(--gold)] transition"
                >
                  @turismoitatinga
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-6 mt-10 pt-6 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-white/50">
          <p>
            © {new Date().getFullYear()} Prefeitura Municipal de Itatinga. Todos os direitos reservados.
          </p>
          <p className="text-center md:text-right">
            As informações deste site poderão ser atualizadas pela organização do evento.
          </p>
        </div>
      </footer>
    </div>
  );
}
