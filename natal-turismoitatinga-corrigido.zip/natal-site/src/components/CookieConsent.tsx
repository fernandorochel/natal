import { useEffect, useState } from "react";
import { Cookie, X } from "lucide-react";

const STORAGE_KEY = "cookie-consent:v1";

type Choice = "accepted" | "essential";

export default function CookieConsent() {
  const [visible, setVisible] = useState(false);
  const [showPolicy, setShowPolicy] = useState(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (!saved) {
        // pequeno atraso para não competir com a hidratação
        const t = setTimeout(() => setVisible(true), 600);
        return () => clearTimeout(t);
      }
    } catch {
      setVisible(true);
    }
  }, []);

  const persist = (choice: Choice) => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ choice, at: new Date().toISOString() })
      );
    } catch {
      /* storage indisponível — segue sem persistir */
    }
    setVisible(false);
  };

  if (!visible && !showPolicy) return null;

  return (
    <>
      {visible && (
        <div
          role="dialog"
          aria-live="polite"
          aria-label="Aviso de cookies e privacidade"
          className="fixed bottom-4 left-4 right-4 md:left-6 md:right-auto md:bottom-6 md:max-w-md z-[80] animate-in fade-in slide-in-from-bottom-4"
        >
          <div className="glass rounded-2xl border border-[color:var(--gold)]/30 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.6)] p-5 md:p-6 backdrop-blur-xl">
            <div className="flex items-start gap-3">
              <div className="shrink-0 w-10 h-10 rounded-full flex items-center justify-center bg-[color:var(--gold)]/15 border border-[color:var(--gold)]/30">
                <Cookie className="w-5 h-5 text-[color:var(--gold)]" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs tracking-[0.3em] text-[color:var(--gold)] mb-1.5">
                  PRIVACIDADE
                </p>
                <h3 className="font-serif text-lg text-white mb-1.5">
                  Sua privacidade importa
                </h3>
                <p className="text-sm text-white/70 leading-relaxed">
                  Utilizamos apenas cookies essenciais para o funcionamento do
                  site. Nenhum dado pessoal é coletado sem seu consentimento,
                  conforme a{" "}
                  <button
                    onClick={() => setShowPolicy(true)}
                    className="underline decoration-[color:var(--gold)]/60 underline-offset-2 hover:text-[color:var(--gold)] transition"
                  >
                    LGPD
                  </button>
                  .
                </p>
              </div>
              <button
                onClick={() => persist("essential")}
                aria-label="Fechar aviso"
                className="shrink-0 text-white/50 hover:text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 flex flex-col sm:flex-row gap-2">
              <button
                onClick={() => persist("essential")}
                className="flex-1 px-4 py-2.5 rounded-full text-xs uppercase tracking-widest border border-white/15 text-white/80 hover:border-[color:var(--gold)]/60 hover:text-white transition"
              >
                Somente essenciais
              </button>
              <button
                onClick={() => persist("accepted")}
                className="flex-1 btn-gold px-4 py-2.5 rounded-full text-xs uppercase tracking-widest hover:-translate-y-0.5 transition"
              >
                Aceitar todos
              </button>
            </div>
          </div>
        </div>
      )}

      {showPolicy && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Aviso de privacidade"
          className="fixed inset-0 z-[90] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
          onClick={() => setShowPolicy(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="glass rounded-2xl border border-white/10 max-w-lg w-full p-6 md:p-8 max-h-[80vh] overflow-y-auto"
          >
            <div className="flex items-start justify-between gap-4 mb-4">
              <div>
                <p className="text-xs tracking-[0.3em] text-[color:var(--gold)] mb-1">
                  LGPD
                </p>
                <h3 className="font-serif text-2xl text-white">
                  Aviso de Privacidade
                </h3>
              </div>
              <button
                onClick={() => setShowPolicy(false)}
                aria-label="Fechar"
                className="text-white/60 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-3 text-sm text-white/75 leading-relaxed">
              <p>
                Este site é uma página institucional informativa e{" "}
                <strong className="text-white">não coleta dados pessoais</strong>{" "}
                por meio de formulários, cadastros ou APIs.
              </p>
              <p>
                Utilizamos apenas armazenamento local técnico
                (<code className="text-[color:var(--gold)]">localStorage</code>){" "}
                para lembrar sua escolha sobre este aviso — considerado cookie
                essencial pela LGPD (Lei nº 13.709/2018).
              </p>
              <p>
                Não usamos cookies de marketing, rastreamento ou perfilamento.
                Ao clicar em links externos (Instagram, WhatsApp), você passa a
                ser regido pela política de privacidade desses serviços.
              </p>
              <p className="text-white/60">
                Dúvidas sobre tratamento de dados? Entre em contato pela seção
                &quot;Contato&quot; deste site.
              </p>
            </div>
            <button
              onClick={() => {
                setShowPolicy(false);
                if (visible) persist("essential");
              }}
              className="mt-6 w-full btn-gold px-4 py-2.5 rounded-full text-xs uppercase tracking-widest hover:-translate-y-0.5 transition"
            >
              Entendi
            </button>
          </div>
        </div>
      )}
    </>
  );
}
