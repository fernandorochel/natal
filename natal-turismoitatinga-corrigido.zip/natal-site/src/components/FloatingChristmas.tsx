import { useEffect, useState } from "react";
import santa from "@/assets/floating/santa.png";
import mrsClaus from "@/assets/floating/mrs-claus.png";
import reindeer from "@/assets/floating/reindeer.png";
import snowman from "@/assets/floating/snowman.png";

const CHARACTERS = [santa, mrsClaus, reindeer, snowman];

type Floater = {
  id: number;
  src: string;
  top: number; // vh
  duration: number; // s
  delay: number; // s
  direction: "ltr" | "rtl";
  size: number; // px
  drift: number; // vh vertical drift
};

let counter = 0;

function makeFloater(): Floater {
  counter += 1;
  const direction = Math.random() > 0.5 ? "ltr" : "rtl";
  return {
    id: counter,
    src: CHARACTERS[Math.floor(Math.random() * CHARACTERS.length)],
    top: 10 + Math.random() * 70,
    duration: 28 + Math.random() * 22,
    delay: Math.random() * 4,
    direction,
    size: 90 + Math.random() * 50,
    drift: (Math.random() - 0.5) * 20,
  };
}

export default function FloatingChristmas() {
  const [floaters, setFloaters] = useState<Floater[]>([]);
  const [enabled, setEnabled] = useState(true);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const isMobile = window.matchMedia("(max-width: 768px)").matches;
    if (reduced || isMobile) {
      setEnabled(false);
      return;
    }
    const maxOnScreen = 1;
    setFloaters([makeFloater()]);
    const interval = setInterval(() => {
      setFloaters((prev) => {
        if (prev.length >= maxOnScreen) return prev;
        return [...prev, makeFloater()];
      });
    }, 22000);

    return () => clearInterval(interval);
  }, []);

  const handleEnd = (id: number) => {
    setFloaters((prev) => prev.filter((f) => f.id !== id));
  };

  if (!enabled) return null;

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 overflow-hidden"
      style={{ zIndex: 1 }}
    >
      {floaters.map((f) => (
        <div
          key={f.id}
          onAnimationEnd={() => handleEnd(f.id)}
          className="absolute will-change-transform"
          style={{
            top: `${f.top}vh`,
            left: f.direction === "ltr" ? `-${f.size}px` : "auto",
            right: f.direction === "rtl" ? `-${f.size}px` : "auto",
            animation: `${f.direction === "ltr" ? "fx-cross-ltr" : "fx-cross-rtl"} ${f.duration}s linear ${f.delay}s 1 forwards`,
            // @ts-expect-error custom prop
            "--drift": `${f.drift}vh`,
          }}
        >
          <img
            src={f.src}
            alt=""
            width={f.size}
            height={f.size}
            loading="lazy"
            decoding="async"
            className="select-none opacity-40 md:opacity-50"
            style={{
              width: `${f.size}px`,
              height: `${f.size}px`,
              animation: `fx-hover 3.5s ease-in-out infinite`,
              filter: "drop-shadow(0 8px 20px rgba(0,0,0,0.35))",
            }}
          />
        </div>
      ))}
      <style>{`
        @keyframes fx-cross-ltr {
          0%   { transform: translate3d(0, 0, 0); }
          100% { transform: translate3d(calc(100vw + 200px), var(--drift, 0), 0); }
        }
        @keyframes fx-cross-rtl {
          0%   { transform: translate3d(0, 0, 0); }
          100% { transform: translate3d(calc(-100vw - 200px), var(--drift, 0), 0); }
        }
        @keyframes fx-hover {
          0%, 100% { transform: translateY(0) rotate(-2deg); }
          50%      { transform: translateY(-12px) rotate(2deg); }
        }
        @media (max-width: 768px) {
          [data-floating-xmas] img { opacity: 0.5 !important; }
        }
      `}</style>
    </div>
  );
}
